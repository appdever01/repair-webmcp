# @iconjar/stroke-standard

Private, full-featured stroke-standard Hugeicons Pro icons for authorized Iconjar projects.

## Per-icon import

```tsx
import BinaryIcon from "@iconjar/stroke-standard/BinaryIcon";
import HugeiconsIcon from "@iconjar/stroke-standard/react";

<HugeiconsIcon icon={BinaryIcon} size={24} />
```

## Named import

```ts
import { BinaryIcon } from "@iconjar/stroke-standard";
```

## Other renderers

Use `@iconjar/stroke-standard/react-native`, `@iconjar/stroke-standard/vue`, `@iconjar/stroke-standard/angular`, or `@iconjar/stroke-standard/svelte` after installing that framework's official `@hugeicons/*` renderer.

## Dynamic loading

```ts
import { loadIcon } from "@iconjar/stroke-standard/loader";

const BinaryIcon = await loadIcon("BinaryIcon");
```

## SVG and JSON

```ts
import BinaryIcon from "@iconjar/stroke-standard/BinaryIcon";
import { iconToDataUri, iconToJson, iconToSvg } from "@iconjar/stroke-standard/svg";

const svg = iconToSvg(BinaryIcon, { title: "Binary", primaryColor: "#111827" });
```
