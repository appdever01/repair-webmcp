export * from "@hugeicons/angular";
export { HugeiconsIconComponent as default } from "@hugeicons/angular";
