const renderer = require("@hugeicons/react-native");
module.exports = { ...renderer, default: renderer.HugeiconsIcon };
