export * from "@hugeicons/react-native";
export { HugeiconsIcon as default } from "@hugeicons/react-native";
