const renderer = require("@hugeicons/react");
module.exports = { ...renderer, default: renderer.HugeiconsIcon };
