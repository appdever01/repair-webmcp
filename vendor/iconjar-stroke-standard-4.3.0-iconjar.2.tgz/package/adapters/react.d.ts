export * from "@hugeicons/react";
export { HugeiconsIcon as default } from "@hugeicons/react";
