const renderer = require("@hugeicons/svelte");
module.exports = { ...renderer, default: renderer.HugeiconsIcon };
