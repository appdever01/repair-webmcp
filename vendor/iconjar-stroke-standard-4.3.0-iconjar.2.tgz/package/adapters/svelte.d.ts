export * from "@hugeicons/svelte";
export { HugeiconsIcon as default } from "@hugeicons/svelte";
