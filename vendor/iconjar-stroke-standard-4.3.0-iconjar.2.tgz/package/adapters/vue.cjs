const renderer = require("@hugeicons/vue");
module.exports = { ...renderer, default: renderer.HugeiconsIcon };
