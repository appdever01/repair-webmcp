export * from "@hugeicons/vue";
export { HugeiconsIcon as default } from "@hugeicons/vue";
