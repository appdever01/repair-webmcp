export type IconSvgElement = readonly (readonly [string, Readonly<Record<string, string | number>>])[];
declare const icon: IconSvgElement;
export default icon;
