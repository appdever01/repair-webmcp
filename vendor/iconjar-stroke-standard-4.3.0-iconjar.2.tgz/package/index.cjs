const icons = require("./dist/cjs/index.js");
module.exports = { ...icons, style: "stroke-standard", sourcePackage: "@hugeicons-pro/core-stroke-standard", sourceVersion: "4.3.0", packageVersion: "4.3.0-iconjar.2", iconCount: 6025 };
