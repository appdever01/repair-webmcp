export * from "./dist/types/index";
export declare const style: "stroke-standard";
export declare const sourcePackage: "@hugeicons-pro/core-stroke-standard";
export declare const sourceVersion: "4.3.0";
export declare const packageVersion: "4.3.0-iconjar.2";
export declare const iconCount: 6025;
