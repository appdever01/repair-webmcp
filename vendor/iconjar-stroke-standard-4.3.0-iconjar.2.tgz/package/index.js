export * from "./dist/esm/index.js";
export const style = "stroke-standard";
export const sourcePackage = "@hugeicons-pro/core-stroke-standard";
export const sourceVersion = "4.3.0";
export const packageVersion = "4.3.0-iconjar.2";
export const iconCount = 6025;
