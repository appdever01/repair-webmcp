export type IconAttributeValue = string | number;
export type SvgAttributeValue = IconAttributeValue | boolean;
export type IconAttributes = Readonly<Record<string, IconAttributeValue>>;
export type IconSvgElement = readonly (readonly [string, IconAttributes])[];
export interface IconToSvgOptions {
  size?: string | number;
  color?: string;
  strokeWidth?: number;
  absoluteStrokeWidth?: boolean;
  primaryColor?: string;
  secondaryColor?: string;
  disableSecondaryOpacity?: boolean;
  title?: string;
  className?: string;
  attributes?: Record<string, SvgAttributeValue | null | undefined>;
}
export declare function iconToSvg(icon: IconSvgElement, options?: IconToSvgOptions): string;
export declare function iconToDataUri(icon: IconSvgElement, options?: IconToSvgOptions): string;
export declare function iconToJson(icon: IconSvgElement, spacing?: number): string;
