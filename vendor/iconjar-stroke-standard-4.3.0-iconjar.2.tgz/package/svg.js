const attributeAliases = {
  className: "class",
  htmlFor: "for",
  tabIndex: "tabindex",
  xlinkHref: "xlink:href",
};

function escapeXml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll('"', "&quot;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function attributeName(name) {
  return attributeAliases[name] || name.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
}

function serializeAttributes(attributes) {
  return Object.entries(attributes)
    .filter(([name, value]) => name !== "key" && value !== undefined && value !== null && value !== false)
    .map(([name, value]) => `${attributeName(name)}="${escapeXml(value === true ? "" : value)}"`)
    .join(" ");
}

function iconToSvg(icon, options = {}) {
  if (!Array.isArray(icon)) throw new TypeError("icon must be a Hugeicons icon-data array");
  const {
    size = 24,
    color = "currentColor",
    strokeWidth,
    absoluteStrokeWidth = false,
    primaryColor,
    secondaryColor,
    disableSecondaryOpacity = false,
    title,
    className,
    attributes = {},
  } = options;
  const calculatedStrokeWidth = strokeWidth === undefined
    ? undefined
    : absoluteStrokeWidth
      ? (Number(strokeWidth) * 24) / Number(size)
      : strokeWidth;
  const rootAttributes = {
    xmlns: "http://www.w3.org/2000/svg",
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    color: primaryColor || color,
    className,
    role: title ? "img" : undefined,
    ...attributes,
  };
  const children = [...icon]
    .sort(([, first], [, second]) => {
      const firstHasOpacity = first.opacity !== undefined;
      const secondHasOpacity = second.opacity !== undefined;
      return secondHasOpacity ? 1 : firstHasOpacity ? -1 : 0;
    })
    .map(([tag, sourceAttributes]) => {
      if (!/^[a-z][a-z0-9]*$/i.test(tag)) throw new TypeError(`Unsupported SVG element: ${tag}`);
      const isSecondary = sourceAttributes.opacity !== undefined;
      const elementAttributes = { ...sourceAttributes };
      delete elementAttributes.key;
      if (calculatedStrokeWidth !== undefined) {
        elementAttributes.strokeWidth = calculatedStrokeWidth;
        elementAttributes.stroke = "currentColor";
      }
      if (secondaryColor) {
        if (sourceAttributes.stroke !== undefined) {
          elementAttributes.stroke = isSecondary ? secondaryColor : (primaryColor || color);
        } else {
          elementAttributes.fill = isSecondary ? secondaryColor : (primaryColor || color);
        }
      }
      if (isSecondary && disableSecondaryOpacity) delete elementAttributes.opacity;
      const serialized = serializeAttributes(elementAttributes);
      return `<${tag}${serialized ? ` ${serialized}` : ""}></${tag}>`;
    })
    .join("");
  const serializedRoot = serializeAttributes(rootAttributes);
  const titleElement = title === undefined ? "" : `<title>${escapeXml(title)}</title>`;
  return `<svg ${serializedRoot}>${titleElement}${children}</svg>`;
}

function iconToDataUri(icon, options = {}) {
  return `data:image/svg+xml,${encodeURIComponent(iconToSvg(icon, options))}`;
}

function iconToJson(icon, spacing = 0) {
  if (!Array.isArray(icon)) throw new TypeError("icon must be a Hugeicons icon-data array");
  return JSON.stringify(icon, null, spacing);
}

export { iconToDataUri, iconToJson, iconToSvg };
